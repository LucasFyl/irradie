<?php if(!defined('KIRBY')) exit ?>

username: admin
email: lfayolle1@gmail.com
password: >
  $2a$10$wMvS5lxS9lI6zPAibVS5ZeAea9IJdlSIf1Dll2K7YNMGdjiYUpTpm
language: en
role: admin
history:
  - error
  - about
  - work/incendiaire
  - work/dark-sand
  - work/liberation
firstname: Lucas
lastname: Fayolle
