<?php snippet('head') ?>

  <div id="main" class="main <?php echo $page->id() ?>">
    <?php snippet('header') ?>


    <?php snippet('projects'); ?>

  </div>

<?php snippet('footer') ?>
