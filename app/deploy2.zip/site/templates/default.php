<?php snippet('head') ?>
<?php snippet('header') ?>

<?php snippet('footer') ?>
