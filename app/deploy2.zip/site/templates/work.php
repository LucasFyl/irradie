<?php snippet('head') ?>

  <div class="main" role="main">
      <?php snippet('header') ?>

      <?php snippet('projects'); ?>

  </div>

<?php snippet('footer') ?>
