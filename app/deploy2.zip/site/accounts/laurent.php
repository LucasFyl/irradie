<?php if(!defined('KIRBY')) exit ?>

username: laurent
firstname: Laurent
lastname: Vonck
email: laurent@irradie.com
password: >
  $2a$10$1nczRooJQkRwLNICPZz74eqKJsmaNRhnGHwxvsBLg7a1WGbPpVR7u
language: fr
role: admin
