<?php if(!defined('KIRBY')) exit ?>

username: alain
firstname: Alain
lastname: Vonck
email: alain@irradie.com
password: >
  $2a$10$t5Rc2U999CLyJG3qHhWB.OQCEZSSU8a./Szx6eEmDsQhl4WI9BwPu
language: fr
role: admin
